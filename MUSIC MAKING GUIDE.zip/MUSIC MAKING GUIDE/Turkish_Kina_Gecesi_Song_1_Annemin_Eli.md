# Turkish Kına Gecesi Song 1: "Annemin Eli" (Mother's Hand)

## Song Creation Notes
Traditional Turkish henna night song emphasizing the emotional farewell between mother and daughter. Features minimalist Turkish lyrics with authentic folk instrumentation.

---

## **Suno AI Prompt - Song 1**

### **Song Title:** Annemin Eli (Mother's Hand)

### **Style of Music Section:**
Traditional Turkish Folk Ballad, Melancholic, Heartfelt, 85 BPM. Features fingerpicked bağlama (saz) as lead melody, gentle darbuka rhythm, haunting ney flute interludes, and emotional female vocals with traditional Turkish folk delivery. Evokes the atmosphere of an Anatolian village henna ceremony, with authentic Turkish makam scales and the sorrowful beauty of a bride's farewell.

### **Lyrics Section:**
[suno tags]

[Intro - Bağlama Solo]
[Fingerpicked saz, slow and contemplative]

[Verse 1]
Annemin eli kınalı
(Mother's hand is with henna)
Benim elim boş kaldı
(My hand remained empty)
Evimizin kapısında
(At our home's doorstep)
Gözyaşım sel oldu
(My tears became a flood)

[Chorus - Ney enters softly]
Aman anne, aman baba
(Oh mother, oh father)
Nasıl ayrılır kızınız
(How can your daughter leave)
Bu henna gecesinde
(In this henna night)
Nasıl gider yavrunuz
(How does your little one go)

[Verse 2]
[Darbuka gentle rhythm]
Kırmızı örtü başımda
(Red veil upon my head)
Mumlara bakıyorum
(I look at the candles)
Annemin sesini duyup
(Hearing my mother's voice)
Yüreğim yanıyor
(My heart is burning)

[Bridge - Instrumental]
[Bağlama and ney duet, melancholic]

[Final Chorus]
[Emotional build, all instruments]
Aman anne, aman baba
(Oh mother, oh father)
Dualar edin bana
(Pray for me)
Bu kına gecesinde
(In this henna night)
Bereket verin bana
(Give me your blessing)

[Outro]
[Bağlama solo, fading]
[Soft ney final note]

### **Excluded Styles Section:**
electric guitar, synthesizers, auto-tune, modern drums, bass guitar, pop production